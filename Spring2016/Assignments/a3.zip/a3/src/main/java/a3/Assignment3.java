package a3;

import java.text.MessageFormat;
import java.util.Scanner;

public class Assignment3 {

	/**
	 * Asks user for a number between low and high (inclusive), reads it. 
	 * Keeps reading until user enters a number within range (inclusive). USE RECURSION
	 * @param in - The Scanner to read from (I'm giving you the Scanner; do NOT read from System.in
	 * @param low - the lowest acceptable number
	 * @param high - the highest acceptable number
	 * @return the number read
	 * Your implementation needs to be RECURSIVE
	 */
	public static int readWithinRange(Scanner in, int low, int high)
	{
		// notice I'm passing the Scanner already; do NOT read from System.in
		return 0;
	}
	
	/**
	 * use a switch statement for this function (no ifs allowed)
	 * 1=January, 2=February ... 12=December (notice they start with uppercase)
	 * return "Invalid Month" if not between 1 and 12.
	 * @return 
	 */
	public static String monthName(int month)
	{
		return "Invalid Month";
	}

	/**
	 * use one or more if statements for this function (no switch allowed)
	 * 1=January, 2=February ... 12=December (notice they start with uppercase)
	 * return "Invalid Month" if not between 1 and 12.
	 * @return 
	 */
	public static String monthName_if(int month)
	{
		return "Invalid Month";
	}
	/**
	 * Use RECURSION to write this function.
	 * The function gets a strin, say a and an int, say n, and returns a new string containing a n times.
	 *   Example: 	stringTimes("abc",3) => "abcabcabc"
	 *   			stringTimes("Hola",2) => "HolaHola"
	 *   			stringTimes("Abc",0) => "" 
	 * @param theString - the string to replicate
	 * @param times - you can safely assume times>=0
	 */
	public static String stringTimes(String theString, int times)
	{
		return "";
	}
	
	public static void main(String[] args) {
		// use readWithinRange to read a number between 1 and 12
		// then use monthName and stringTimes to print the corresponding month name that number of times
		// so if you read 2, you'd print FebruaryFebruary ; if you read 3 you'd print MarchMarchMarch
	}

}
