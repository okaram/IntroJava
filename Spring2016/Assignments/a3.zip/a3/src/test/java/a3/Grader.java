package a3;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.okaram.grading.Grade;


public class Grader {

	static List<String> monthNames=Arrays.asList(
			"Invalid Month",
			"January",
			"February",
			"March",
			"April",
			"May",
			"June",
			"July",
			"August",
			"September",
			"October",
			"November",
			"December",
			"Invalid Month"
	);
	
	@Grade(points=20)
	@Test
	public void testMonthName()
	{
		for(int i=0; i<monthNames.size();++i) {
			Assert.assertEquals(monthNames.get(i), Assignment3.monthName(i));
		}
	}
	
	@Grade(points=20)
	@Test
	public void testMonthName_if()
	{
		for(int i=0; i<monthNames.size();++i) {
			Assert.assertEquals(monthNames.get(i), Assignment3.monthName_if(i));
		}
	}
	
	@Grade(points=10)
	@Test
	public void testStringTimes1()
	{
		Assert.assertEquals("", Assignment3.stringTimes("abc", 0));
		Assert.assertEquals("abc", Assignment3.stringTimes("abc", 1));
	}

	@Grade(points=10)
	@Test
	public void testStringTimes2()
	{
		Assert.assertEquals("HiHiHiHi", Assignment3.stringTimes("Hi", 4));
		Assert.assertEquals("123123123", Assignment3.stringTimes("123", 3));
	}	

	@Grade(points=10)
	@Test
	public void testReadWithinRange()
	{
        PrintStream oriOut=System.out;
        InputStream in = new ByteArrayInputStream( " 10 20".getBytes() );
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        
        System.setOut(new PrintStream(out));
        Scanner in_s=new Scanner(in);
        int ans=Assignment3.readWithinRange(in_s,15,25);
        Assert.assertEquals(20, ans);
        
        System.setOut(oriOut);
	}

	@Grade(points=10)
	@Test
	public void testReadWithinRange2()
	{
        PrintStream oriOut=System.out;
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        
        System.setOut(new PrintStream(out));
        Scanner in_s=new Scanner(new ByteArrayInputStream( "10 20".getBytes() ));
        int ans=Assignment3.readWithinRange(in_s,10,20);
        Assert.assertEquals(10, ans);
        in_s=new Scanner(new ByteArrayInputStream( "10 20 21".getBytes() ));
        Assert.assertEquals(21, Assignment3.readWithinRange(in_s,21,30));
        
        System.setOut(oriOut);
	}

}