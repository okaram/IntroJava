package okaram.a2;

import java.text.MessageFormat;
import java.util.Scanner;

public class Assignment2 {
	
	/**
	 * This is a sample for you to get started.
	 * This method reads one integer from the standard input(keyboard) 
	 * @return twice the number read, an int.
	 */
	public static int readAndDouble()
	{
		Scanner in=new Scanner(System.in);
		System.out.println("Please enter a number");
		int number=in.nextInt();
		return 2*number;
	}
	
	/**
	 * YOU NEED TO IMPLEMENT THIS
	 * Need to read two numbers from the keyboard, and return their sum
	 * @return the sum of the two numbers read
	 */
	public static int readAndAdd()
	{
        // Pseudo-code for you:
        // create Scanner from System.in
        // read number 1 and store in a variable
        // read number 2 and store in a variable
        // return the sum
        return 0;
	}
	
	/** 
	 * YOU NEED TO IMPLEMENT THIS
	 * Need to read two numbers from the keyboard, and return their product
	 * @return the product of the two numbers read
	 */
	public static int readAndMultiply()
	{
		return 0;
	}

	/**
	 * This function takes two parameters, and prints their sum, difference, product, quotient and remainder.
	 * Preferably, print a message before it, like "The sum of 3 and 5 is 8"
	 * @param number1
	 * @param number2
	 */
	public static void printAllOperations(int number1, int number2)
	{
	}

	/**
	 * This function should:
	 *   1. Call readAndAdd to get a value
	 *   2. Call readAndMultiply to get another value
	 *   3. Call printAllOperations with those two values (in that order)
	 * @param args unused, will see later
	 */
	public static void main(String args[])
	{
	}
	
}