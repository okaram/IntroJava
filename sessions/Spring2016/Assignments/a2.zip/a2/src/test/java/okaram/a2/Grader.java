package okaram.a2;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.okaram.grading.Grade;

public class Grader {
	
	InputStream originalStdIn;
	PrintStream originalStdOut;
	
	@Before
	public void captureIO()
	{
		originalStdIn=System.in;
		originalStdOut=System.out;
	}
	
	@After
	public void restoreIO() 
	{
		System.setIn(originalStdIn);
		System.setOut(originalStdOut);
	}
	
	@Test
	@Grade(points=15)
	public void testAdd_123_456(){
		
		InputStream in = new ByteArrayInputStream( "123\n456".getBytes() );
		ByteArrayOutputStream out=new ByteArrayOutputStream();
		
		System.setIn(in);
		System.setOut(new PrintStream(out));
		
		int ans=Assignment2.readAndAdd();
		Assert.assertEquals(579, ans);			
	}
	
	@Test
	@Grade(points=10)
	public void testAdd_11_222(){
		
		InputStream in = new ByteArrayInputStream( "11 222".getBytes() );
		ByteArrayOutputStream out=new ByteArrayOutputStream();
		
		System.setIn(in);
		System.setOut(new PrintStream(out));
		
		int ans=Assignment2.readAndAdd();
		Assert.assertEquals(233, ans);			
	}
	
	@Test
	@Grade(points=15)
	public void testMultiply_10_20(){
		
		InputStream in = new ByteArrayInputStream( "10 20".getBytes() );
		ByteArrayOutputStream out=new ByteArrayOutputStream();
		
		System.setIn(in);
		System.setOut(new PrintStream(out));
		
		int ans=Assignment2.readAndMultiply();
		Assert.assertEquals(200, ans);			
	}

	@Test
	@Grade(points=10)
	public void testMultiply_8_12(){
		
		InputStream in = new ByteArrayInputStream( "8 12".getBytes() );
		ByteArrayOutputStream out=new ByteArrayOutputStream();
		
		System.setIn(in);
		System.setOut(new PrintStream(out));
		
		int ans=Assignment2.readAndMultiply();
		Assert.assertEquals(96, ans);			
	}
	
	@Test
	@Grade(points=15)
	public void testPrintAll_9_7(){
		
		ByteArrayOutputStream out=new ByteArrayOutputStream();
		
		System.setOut(new PrintStream(out));
		
		Assignment2.printAllOperations(9,7);

		String output=new String(out.toByteArray());
		Assert.assertTrue(output.contains("63"));
		Assert.assertTrue(output.contains("16"));
		Assert.assertTrue(output.contains("2"));
	}
	
	@Test
	@Grade(points=10)
	public void testPrintAll_16_5(){
		
		ByteArrayOutputStream out=new ByteArrayOutputStream();
		
		System.setOut(new PrintStream(out));
		
		Assignment2.printAllOperations(16,5);

		String output=new String(out.toByteArray());
		Assert.assertTrue(output.contains("80"));
		Assert.assertTrue(output.contains("11"));
		Assert.assertTrue(output.contains("21"));
		Assert.assertTrue(output.contains("3"));
	}

}
