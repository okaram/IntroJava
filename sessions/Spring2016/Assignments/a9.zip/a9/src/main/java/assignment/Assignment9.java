package assignment;

import java.text.MessageFormat;
import java.util.Scanner;

import java.awt.Point;
import java.awt.Dimension;
import java.awt.Rectangle;

import java.time.LocalDate;

import java.util.*; // List, ArrayList, Map, HashMap
 
class Review {
	public String reviewText;
	public int numberOfStars;
	
	public Review(String reviewText, int numberOfStars) {
		this.reviewText=reviewText;
		this.numberOfStars=numberOfStars;
	}
}

class GameInfo {
	private String title;
	// you need to use a List of reviews (rather than an array) to keep the reviews
	// can add any other fields, but my solution doesn't include any
	public GameInfo(String title) {
		this.title=title;
		// you may want to initialize any other variables you create here
	}
	
	public String getTitle() {
		return title;
	}
	
    // use an ArrayList (instead of an array) to keep track of reviews 	
    List<Review> reviews=new ArrayList<Review>();
	// TODO - adds the review to the list of reviews. You need to keep all reviews in a List<Review>
	public void addReview(Review r) {
	}

	// TODO - returns the number of reviews which have been added to this GameInfo
	public int getNumberOfReviews() {
		return 0;
	}
	
	// TODO - returns the sum of the number of stars which have been added to this GameInfo
	// you have to calculate this from your array
	public int getSumOfStars() {
		int sum=0;
		return sum;
	}

	// TODO - returns the average number of stars for this GameInfo's reviews
	// again, have to calculate this (or at least the sum of stars) from your array
	public double getAverageStarRating() {
		return 0;
	}
}

class GameInfoCollection {
    // TODO - you need to use a Map (from a String, the title, to a GameInfo) to keep track of all the GameInfo's
    private Map<String, GameInfo> theGames=new HashMap<String,GameInfo>();
    

    // TODO - if there are no reviews for the game, create a new GameInfo  (with this review) and add it to the map
    // if there's one, add the given review to the corresponding GameInfo 
    public void addGameReview(String gameTitle, Review r)
    {
    }
    
    public int getNumberOfReviewsForGame(String gameTitle)
    {
        return 0;
    }
    
    public double getAverageNumberOfStarsForGame(String gameTitle)
    {
        return 0;
    }
    
}

public class Assignment9 {
	
	// TODO - calculate the product of an array of ints. Can assume array is not empty
	public static int getListProduct(List<Integer> arr) {
		int product=2;
		return product;
	}
		
	
	public static void main(String[] args) {
		// you can use this as you wish to test or exercise your function. Not graded.
	}
}


