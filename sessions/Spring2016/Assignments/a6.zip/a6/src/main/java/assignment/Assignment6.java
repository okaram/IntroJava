package assignment;

import java.text.MessageFormat;
import java.util.Scanner;

import java.awt.Point;
import java.awt.Dimension;
import java.awt.Rectangle;

import java.time.LocalDate;

/**
 * This class represents a turtle, like a Logo-like turtle, which keeps its position.
 * The turtle keeps its x and y position, and has methods moveNorth() etc which change it
 * Assume normal math coordinates and map convention, so as you move up (North) y increases, and as you move East x increases.
 *
 */
class Turtle {

	// TODO - you may want to have variables to keep the position. Keep these variables private,
	
	// TODO - The empty constructor initializes position to 10,10
	public Turtle() {
	}
		
	public int getX() { 
        // TODO - should return the value of the X coordinate
        return 0;
    }
	public int getY() {
        // TODO - should return the value of the Y coordinate
        return 0;
    }
	
	public void moveNorth() {
		// TODO - this increments the y coordinate by one unit
		
	}
	
	public void moveSouth() {
		// TODO - this decrements the y coordinate by one unit
		
	}
	
	public void moveEast() {
		// TODO - this increments the x coordinate by one unit
		
	}
	
	public void moveWest() {
		// TODO - this decrements the x coordinate by one unit
		
	}
	
	public String toString() {
		return "Turtle[x="+getX()+", y="+getY()+"]";
	}
	
	public boolean equals(Turtle t)
	{
        // TODO: implement this. Two turtles are equal if their coordinates are equal
        return false;
	}
	
	public void move(String direction)
	{
        // TODO - implement this. Move in the appropriate direction (North, South, East or West). Do not do anythhing if not given one of these directions.
	}
}

public class Assignment6 {

	public static void moveTurtleEast(Turtle t, int n)
	{
        // given as an example
		for(int i=0;i<n;++i) 
			t.moveEast();
	}
	
	public static void moveTurtleWest(Turtle t, int n)
	{
        // TODO - implement this. Move the turtle to the west n units. Can assume n>=0
	}
	public static void moveTurtleNorth(Turtle t, int n)
	{
        // TODO - implement this. Move the turtle to the north n units. Can assume n>=0
	}
	public static void moveTurtleSouth(Turtle t, int n)
	{
        // given as an example
		for(int i=0;i<n;++i) 
			t.moveSouth();
	}
	
	public static void moveTurtleTo(Turtle t, int x, int y)
	{
        // TODO - move the turtle the appropriate number of units north/south/east/west until it reaches the requested position (x,y)
        // May want to use functions defined above	
	}
	public static void main(String[] args) {
		// you can use this as you wish to test or exercise your function. Not graded.
        // BONUS 10 points - create a turtle, ask the user in a loop where does it want to move it to, move it accordingly. 
        // When the user enters Stop, stop and print the position
		Turtle t=new Turtle();
		moveTurtleTo(t,15,16);
		System.out.println(t);	
	}
}


