package assignment;


import org.junit.Assert;
import org.junit.Test;

import com.okaram.grading.Grade;



public class Grader {

	@Grade(points=30)
	@Test
	public void testSquare()
	{		
        Square s=new Square(3);
		Assert.assertEquals(9.0,s.getArea(),0.01);
		Assert.assertEquals(12.0,s.getPerimeter(),0.01);

		s=new Square(4);
		Assert.assertEquals(16.0,s.getArea(),0.01);
		Assert.assertEquals(16.0,s.getPerimeter(),0.01);
	}	

	@Grade(points=30)
	@Test
	public void testRegularPolygon()
	{		
        RegularPolygon s=new RegularPolygon(3,4.0,5.0);
		Assert.assertEquals(30.0,s.getArea(),0.01);
		Assert.assertEquals(12.0,s.getPerimeter(),0.01);

		s=new RegularPolygon(4,4.0,5.0);
		Assert.assertEquals(40.0,s.getArea(),0.01);
		Assert.assertEquals(16.0,s.getPerimeter(),0.01);
	}	

	@Grade(points=10)
	@Test
	public void  testGetShapeInstance()
	{
		IShape s=ShapeFactory.getShapeInstance("square",1,2,3);
		Assert.assertTrue(s instanceof Square );
		
		s=ShapeFactory.getShapeInstance("regular polygon",1,2,3);
		Assert.assertTrue(s instanceof RegularPolygon );
	}

	@Grade(points=15)
	@Test
	public void testAverageArea()
	{		
		IShape[] shapes={new Rectangle(2,3), new Circle(1)};
		Assert.assertEquals(4.57,Assignment8.getAverageArea(shapes),0.01);

		IShape[] shapes2={new Rectangle(2,3)};
		Assert.assertEquals(6,Assignment8.getAverageArea(shapes2),0.01);
	}	

	@Grade(points=15)
	@Test
	public void testAveragePerimeter()
	{		
		IShape[] shapes={new Rectangle(2,3), new Circle(1)};
		Assert.assertEquals(8.14,Assignment8.getAveragePerimeter(shapes),0.01);

		IShape[] shapes2={new Rectangle(2,3)};
		Assert.assertEquals(10,Assignment8.getAveragePerimeter(shapes2),0.01);
	}	
}
