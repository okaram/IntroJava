package assignment;

import java.util.Scanner;
import java.util.Random;

interface IShape  {
	double getArea();
	double getPerimeter();
    String forProblemStatement(); 
}

class Rectangle implements IShape {
	private double width, height;
	public Rectangle(double width, double height) {
		this.width=width;
		this.height=height;
	}
	
	@Override
	public double getArea() { return width*height; }
	
	@Override
	public double getPerimeter() { return 2*(width+height); } 
	
	@Override
	public String toString(){ return "Rectangle[width:"+width+" height:"+height+"]"; }
	
	@Override
	public String forProblemStatement() {
        return "rectangle with width "+ width +" and height "+height+".";
	}
}

class Circle implements IShape {
	private double radius;
	public Circle(double radius) {
		this.radius=radius;
	}
	
	@Override public double getArea() { return Math.PI*radius*radius;}
	@Override public double getPerimeter() {return 2*radius*Math.PI;} 
	@Override public String toString(){ return "Circle[radius:"+radius+"]"; }
    @Override public String forProblemStatement() {
        return "circle with radius "+radius;
    }
}

// TODO - define a class Square and implement functions. The constructor takes one double only (the side of the square).

// TODO - define a class RegularPolygon and implement functions. The constructor takes three parameters, the first is the number of sides (an int), the second is the size size and the third is the apothem.
// I googled for you - http://www.mathwords.com/a/area_regular_polygon.htm :)
// fun extension - make fromProblemStatement use right names for Regular polygons of sm

class ShapeFactory {
	public static Random randomGenerator=new Random();
	public static IShape getShapeInstance(String kindOfShape, double param1, double param2, double param3) {
		kindOfShape=kindOfShape.toLowerCase();
		if(kindOfShape.equals("circle")) {
			return new Circle(param1);
		} else if (kindOfShape.equals("rectangle")) {
			return new Rectangle(param1, param2);
		} 
        // TODO - after you've implemented your Square class, add it here so this 
		//   function may return one. The string should be "square"
		
        // TODO - after you've implemented your RectangularPolygon class, add it here 
		//   so this function may return one. The string should be "regular polygon"
		else
			return null;
	}
	
	public static IShape getRandomShape() {
		String[] shapeNames={"circle", "rectangle", "square", "regular polygon"};
        // TODO - after you've implemented Square and RectangularPolygon, add them to the array above so they work
		int shape=randomGenerator.nextInt(shapeNames.length);
		int param1=randomGenerator.nextInt(10)+1;
		int param2=randomGenerator.nextInt(10)+1;
		int param3=randomGenerator.nextInt(10)+1;
        
        return getShapeInstance(shapeNames[shape],param1,param2,param3);
	}
}

public class Assignment8 {
	
    public static void askAreaProblem(IShape s, double acceptableVariance)
    {
        System.out.println("What is the area of a "+s.forProblemStatement());
        double answer=new Scanner(System.in).nextDouble();
        double area=s.getArea();
        if(Math.abs(answer-area)<=acceptableVariance) {
            System.out.println("Yay ! your answer, "+answer+" is correct");
        } else {
            System.out.println("Sorry :( your answer, "+answer+" is not correct.");
            System.out.println("The correct answer is "+area);
        }
    }
    
    public static void askPerimeterProblem(IShape s, double acceptableVariance)
    {
        System.out.println("What is the perimeter of a "+s.forProblemStatement());
        double answer=new Scanner(System.in).nextDouble();
        double perimeter=s.getPerimeter();
        if(Math.abs(answer-perimeter)<=acceptableVariance) {
            System.out.println("Yay ! your answer, "+answer+" is correct");
        } else {
            System.out.println("Sorry :( your answer, "+answer+" is not correct.");
            System.out.println("The correct answer is "+perimeter);
        }
    }

 
    // TODO - you need to implement this function
    public static double getAverageArea(IShape[] shapes)
    {
    	return 0;
    }
    
    // TODO - you need to implement this function
    public static double getAveragePerimeter(IShape[] shapes)
    {
    	return 0;
    }

    public static void main(String[] args) {
        IShape shp=ShapeFactory.getRandomShape();
        askAreaProblem(shp,.01);
        askPerimeterProblem(shp,.01);
    }
}
