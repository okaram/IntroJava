package assignment;

import java.text.MessageFormat;
import java.util.Scanner;

public class Assignment4 {

	/**
	 * Asks user for a number between low and high (inclusive), reads it. 
	 * Keeps reading until user enters a number within range (inclusive). USE a while (or do-while) loop
	 * @param in - The Scanner to read from
	 * @param low - the lowest acceptable number
	 * @param high - the highest acceptable number
	 * @return the number read
	 * Your implementation needs to use a while or do-while loop
	 */
	public static int readWithinRange(Scanner in, int low, int high)
	{
		// notice I'm passing the Scanner already; do NOT read from System.in
		return 0;
	}
	
	/**
	 * Use a for loop to write this function.
	 * The function gets a string, say a and an int, say n, and returns a new string containing a n times.
	 *   Example: 	stringTimes("abc",3) => "abcabcabc"
	 *   			stringTimes("Hola",2) => "HolaHola"
	 *   			stringTimes("Abc",0) => "" 
	 * @param theString - the string to replicate
	 * @param times - you can safely assume times>=0
	 */
	public static String stringTimes(String theString, int times)
	{
		return "";
	}
	
	public static String FizzBuzz(int number) 
	{
		if( (number%3==0) && (number%5==0)) { // or if (number%15==0), but ...
			return "FizzBuzz";
		}
		else if( number%3 == 0 ) {
			return "Fizz";
		} else if( number%5 == 0 ) {
			return "Buzz";
		} else {
			return ""+number;
		}
	}

	/*
	 * use a for loop to print the appropriate FizzBuzz values (feel free to
	 * call the provided FizzBuzz function) for values from from to to, 
	 * including both of those values. Each value should be printed in a separate line.
	 */
	public static void printFizzBuzz(int from, int to)
	{
	}
	
	/* This function should Return the value of the product of all the numbers
	 * between its two parameters (including the parameters)
	 * Examples:
	 * 		productFromTo(3,5) => 3 * 4 * 5 = 60
	 * 		productFromTo(1,6) => 1* 2 * 3 * 4 * 5 * 6 = 720
	 */
	public static int productFromTo(int from, int to)
	{
		return 0;
	}
	
	/*readAndSumPositives (notice you're given the Scanner, do not use System.in)
	 * reads from user until given 0, Returns sum of the positive numbers read
	 * Examples:
	 *   user enters: 0   => return 0
	 *   user enters 1 2 3 0 => returns 6 (1+2+3)
	 *   user enters 1 -2 3 0 => returns 6 (1+3, skip -2 since it is negative)
	 */
	public static int readAndSumPositives(Scanner in)
	{
		int sum=0;
		return sum;
	}
	
	public static void main(String[] args) {
		// use main as you wish
	}
	
}
