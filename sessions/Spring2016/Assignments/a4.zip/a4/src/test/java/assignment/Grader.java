package assignment;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.okaram.grading.Grade;


public class Grader {

	
	@Grade(points=10)
	@Test
	public void testStringTimes1()
	{
		Assert.assertEquals("", Assignment4.stringTimes("abc", 0));
		Assert.assertEquals("abc", Assignment4.stringTimes("abc", 1));
	}

	@Grade(points=10)
	@Test
	public void testStringTimes2()
	{
		Assert.assertEquals("HiHiHiHi", Assignment4.stringTimes("Hi", 4));
		Assert.assertEquals("123123123", Assignment4.stringTimes("123", 3));
	}	

	@Grade(points=10)
	@Test
	public void testReadWithinRange()
	{
        PrintStream oriOut=System.out;
        InputStream in = new ByteArrayInputStream( " 10 20".getBytes() );
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        
        System.setOut(new PrintStream(out));
        Scanner in_s=new Scanner(in);
        int ans=Assignment4.readWithinRange(in_s,15,25);
        Assert.assertEquals(20, ans);
        
        System.setOut(oriOut);
	}

	@Grade(points=10)
	@Test
	public void testReadWithinRange2()
	{
        PrintStream oriOut=System.out;
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        
        System.setOut(new PrintStream(out));
        Scanner in_s=new Scanner(new ByteArrayInputStream( "10 20".getBytes() ));
        int ans=Assignment4.readWithinRange(in_s,10,20);
        Assert.assertEquals(10, ans);
        in_s=new Scanner(new ByteArrayInputStream( "10 20 21".getBytes() ));
        Assert.assertEquals(21, Assignment4.readWithinRange(in_s,21,30));
        
        System.setOut(oriOut);
	}

	@Grade(points=6)
	@Test
	public void testPrintFizzBuzz1()
	{
		PrintStream oriOut=System.out;
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));
        
        Assignment4.printFizzBuzz(3, 5);
		String output=new String(out.toByteArray());
        Assert.assertTrue(output.contains("Fizz"));
        Assert.assertTrue(output.contains("Buzz"));
        Assert.assertTrue(output.contains("4"));
        
        Assert.assertTrue(!output.contains("3"));
        Assert.assertTrue(!output.contains("5"));
        Assert.assertTrue(!output.contains("FizzBuzz"));
        System.setOut(oriOut);
	}

	@Grade(points=6)
	@Test
	public void testPrintFizzBuzz2()
	{
		PrintStream oriOut=System.out;
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));
        
        Assignment4.printFizzBuzz(8, 11);
		String output=new String(out.toByteArray());
        Assert.assertTrue(output.contains("8"));
        Assert.assertTrue(output.contains("Fizz"));
        Assert.assertTrue(output.contains("Buzz"));
        Assert.assertTrue(output.contains("11"));
        
        Assert.assertTrue(!output.contains("9"));
        Assert.assertTrue(!output.contains("10"));
        Assert.assertTrue(!output.contains("FizzBuzz"));
        System.setOut(oriOut);
	}

	@Grade(points=8)
	@Test
	public void testPrintFizzBuzz3()
	{
		PrintStream oriOut=System.out;
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));
        
        Assignment4.printFizzBuzz(13, 16);
		String output=new String(out.toByteArray());
        Assert.assertTrue(output.contains("13"));
        Assert.assertTrue(output.contains("14"));
        Assert.assertTrue(output.contains("FizzBuzz"));
        Assert.assertTrue(output.contains("16"));
        
        Assert.assertTrue(!output.contains("15"));
        System.setOut(oriOut);
	}
	
	@Grade(points=20)
	@Test
	public void testProductFromTo()
	{
		Assert.assertEquals(120, Assignment4.productFromTo(2,5));
		Assert.assertEquals(720, Assignment4.productFromTo(2,6));
		Assert.assertEquals(60, Assignment4.productFromTo(3,5));
		Assert.assertEquals(840, Assignment4.productFromTo(4,7));
	}

	private static int readAndSumPositivesFrom(String input)
	{
        Scanner in_s=new Scanner(new ByteArrayInputStream( input.getBytes() ));
        int ans=Assignment4.readAndSumPositives(in_s);
        in_s.close();
        return ans;
	}
	
	@Grade(points=20)
	@Test
	public void testReadAndSumPositives()
	{
        PrintStream oriOut=System.out;
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        
        System.setOut(new PrintStream(out));
        Assert.assertEquals(30, readAndSumPositivesFrom("10 20 0 "));
        Assert.assertEquals(20, readAndSumPositivesFrom("10 -20 10 0 "));
        Assert.assertEquals(10, readAndSumPositivesFrom("1 2 -2 3 -3 4 -4 0 "));
                
        System.setOut(oriOut);
	}
	
}
