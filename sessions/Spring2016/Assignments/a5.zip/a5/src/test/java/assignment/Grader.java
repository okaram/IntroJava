package assignment;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.okaram.grading.Grade;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Dimension;


public class Grader {

	
	@Grade(points=15)
	@Test
	public void testPersonEquals()
	{
		Person p_ok=new Person("Orlando","Karam",43);
		Person p_ok2=new Person("Orlando","Karam",43);
		Person p_lc=new Person("Lina","Colli",43);
		
		Assert.assertTrue(Assignment5.personEquals(p_lc,p_lc));
		Assert.assertTrue(Assignment5.personEquals(p_ok,p_ok2));
		Assert.assertFalse(Assignment5.personEquals(p_ok,p_lc));	
	}
	
	@Grade(points=10)
	@Test
	public void testIsToTheRight()
	{
		Point p1=new Point(10,10);
		Point p2=new Point(10,1);
		Point p3=new Point(9,15);
		
		Assert.assertFalse(Assignment5.isToTheRight(p1, p2));
		Assert.assertFalse(Assignment5.isToTheRight(p2, p1));
		Assert.assertTrue(Assignment5.isToTheRight(p1, p3));
		Assert.assertFalse(Assignment5.isToTheRight(p3, p1));
		Assert.assertFalse(Assignment5.isToTheRight(p3, p2));
	}
	
	@Grade(points=15)
	@Test
	public void testIsBelow()
	{
		Point p1=new Point(10,10);
		Point p2=new Point(10,1);
		Point p3=new Point(9,15);
		
		Assert.assertFalse(Assignment5.isBelow(p2, p1));
		Assert.assertTrue(Assignment5.isBelow(p1, p2));
		Assert.assertFalse(Assignment5.isBelow(p2, p3));
	}

	@Grade(points=15)
	@Test
	public void testGetCenter()
	{
		Rectangle r1=new Rectangle(10,10,10,10);
		Rectangle r2=new Rectangle(1,2,10,10);
		Rectangle r3=new Rectangle(10,10,5,10);
		Assert.assertEquals( new Point(15,15),  Assignment5.getCenter(r1));
		Assert.assertEquals( new Point(6,7),  Assignment5.getCenter(r2));
		Assert.assertEquals( new Point(12,15),  Assignment5.getCenter(r3));
	}
	
	@Grade(points=15)
	@Test
	public void testContains()
	{		
		Assert.assertTrue(Assignment5.contains(new Rectangle(0,0,10,10), new Point(5,5)));
		Assert.assertTrue(Assignment5.contains(new Rectangle(0,0,10,10), new Point(0,0)));
		Assert.assertTrue(Assignment5.contains(new Rectangle(0,0,10,10), new Point(0,10)));
		Assert.assertFalse(Assignment5.contains(new Rectangle(0,0,10,10), new Point(11,5)));
		Assert.assertFalse(Assignment5.contains(new Rectangle(0,0,10,10), new Point(5,15)));
	}
	
	@Grade(points=15)
	@Test
	public void testGetFullName()
	{
		Person p_ok=new Person("Orlando","Karam",43);
		Person p_lc=new Person("Lina","Colli",43);

		Assert.assertEquals("Orlando Karam", Assignment5.getFullName(new Person("Orlando","Karam",43)));
		Assert.assertEquals("Lina Colli", Assignment5.getFullName(new Person("Lina","Colli",40)));
	}

	@Grade(points=15)
	@Test
	public void getFormalFullName()
	{

		Assert.assertEquals("Karam, Orlando", Assignment5.getFormalFullName(new Person("Orlando","Karam",43)));
		Assert.assertEquals("Colli, Lina", Assignment5.getFormalFullName(new Person("Lina","Colli",40)));
	}

}
