package okaram.sample;

import org.junit.Assert;
import org.junit.Test;
import com.okaram.grading.Grade;

public class Grader {
	@Test
	@Grade(points=10)
	public void testAdd_10_10(){
		Assert.assertEquals(20, Sample.add(10, 10));
	}

	@Test
	@Grade(points=10)
	public void testAdd_5_8(){
		Assert.assertEquals(13, Sample.add(5, 8));
	}
	
}