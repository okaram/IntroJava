package okaram.sample;

public class Sample {
	
	public static int add(int a, int b){
		return 0;
	}
	
	public static void main(String args[]){
		System.out.println("20 + 10 = "+add(20,10));
	}
}